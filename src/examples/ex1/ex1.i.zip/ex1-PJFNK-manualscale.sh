#!/bin/bash

mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E+02 Outputs/file_base=ex1_PJFNK_1E+05 &> "ex1_PJFNK_1E+05.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E+02 Outputs/file_base=ex1_PJFNK_1E+02 &> "ex1_PJFNK_1E+02.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E+01 Outputs/file_base=ex1_PJFNK_1E+01 &> "ex1_PJFNK_1E+01.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E+00 Outputs/file_base=ex1_PJFNK_1E+00 &> "ex1_PJFNK_1E+00.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E-01 Outputs/file_base=ex1_PJFNK_1E-01 &> "ex1_PJFNK_1E-01.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E-02 Outputs/file_base=ex1_PJFNK_1E-02 &> "ex1_PJFNK_1E-02.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E-03 Outputs/file_base=ex1_PJFNK_1E-03 &> "ex1_PJFNK_1E-03.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E-04 Outputs/file_base=ex1_PJFNK_1E-04 &> "ex1_PJFNK_1E-04.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E-05 Outputs/file_base=ex1_PJFNK_1E-05 &> "ex1_PJFNK_1E-05.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E-10 Outputs/file_base=ex1_PJFNK_1E-10 &> "ex1_PJFNK_1E-10.log"
mpiexec -n 5 /home/mjg/projects/shale/shale-opt -i /home/mjg/projects/shale/models/porous_flow_block/porous_flow_block-PJFNK-manualscale.i Variables/porepressure/scaling=1E-15 Outputs/file_base=ex1_PJFNK_1E-15 &> "ex1_PJFNK_1E-15.log"
